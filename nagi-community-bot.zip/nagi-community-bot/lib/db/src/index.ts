import { drizzle } from "drizzle-orm/node-postgres";
import pg from "pg";
import * as schema from "./schema";

const { Pool } = pg;

if (!process.env.DATABASE_URL) {
  throw new Error(
    "DATABASE_URL must be set. Did you forget to provision a database?",
  );
}

export const pool = new Pool({ connectionString: process.env.DATABASE_URL });
export const db = drizzle(pool, { schema });

export * from "./schema";
export * from "./vcHub";
export * from "./evalSheetConfig";
export * from "./preban";
export * from "./timedRoleGrants";
export * from "./shopForumPanel";
export * from "./uraRecruitment";
export * from "./schema-check";
export * from "./dealerCasino";
export * from "./bounty";
